from flask import Flask, render_template, request
import joblib

app = Flask(__name__)

model = joblib.load('model_recruiter.pkl')

feature_means = {
    'عدد التمريرات': 49.35,
    'دقة التمريرات (%)': 77.89,
    'عدد التسديدات': 4.95,
    'عدد الأهداف': 1.87,
    'نسبة النجاح في المواجهات (%)': 64.93,
    'السرعة القصوى (كم/س)': 29.12,
    'المسافة المقطوعة (كم)': 8.78,
    'معدل نبض القلب': 149.11,
    'نسبة التعب في نهاية الشوط': 29.6
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    input_values = [
        float(request.form['pass_count']),
        float(request.form['pass_accuracy']),
        float(request.form['shots']),
        float(request.form['goals']),
        float(request.form['duel_success']),
        float(request.form['max_speed']),
        float(request.form['distance']),
        float(request.form['heart_rate']),
        float(request.form['fatigue']),
    ]

    features = list(feature_means.keys())
    prediction = model.predict([input_values])[0]
    probability = round(model.predict_proba([input_values])[0][1] * 100, 2)

    comparison = []
    above_count = 0

    for i in range(len(features)):
        player_val = input_values[i]
        mean_val = feature_means[features[i]]
        status = "فوق المتوسط" if player_val > mean_val else "أقل من المتوسط"
        if status == "فوق المتوسط":
            above_count += 1
        comparison.append((features[i], player_val, round(mean_val, 2), status))

    if above_count >= 7:
        level = "ممتاز جدًا"
    elif above_count >= 4:
        level = "جيد"
    else:
        level = "يحتاج تطوير"

    return render_template('result.html',
                           prediction="موهوب" if prediction == 1 else "غير موهوب",
                           probability=probability,
                           comparison=comparison,
                           level=level)

if __name__ == '__main__':
    app.run(debug=True) 
